export const seedBins = [
{id:'BIN-101',zone:'Downtown',lat:27.2579,lng:33.8116,fill:94,weight:188,temp:35,rate:2.6},
{id:'BIN-102',zone:'Downtown',lat:27.2605,lng:33.8173,fill:78,weight:156,temp:32,rate:1.9},
{id:'BIN-103',zone:'Marina',lat:27.2248,lng:33.8412,fill:87,weight:174,temp:36,rate:2.2},
{id:'BIN-104',zone:'Marina',lat:27.2262,lng:33.8379,fill:41,weight:82,temp:30,rate:1.5},
{id:'BIN-105',zone:'Industrial',lat:27.1907,lng:33.8212,fill:98,weight:196,temp:46,rate:1.3},
{id:'BIN-106',zone:'Industrial',lat:27.1942,lng:33.8272,fill:65,weight:130,temp:33,rate:2.0},
{id:'BIN-107',zone:'Downtown',lat:27.2631,lng:33.8081,fill:34,weight:68,temp:29,rate:1.7},
{id:'BIN-108',zone:'Marina',lat:27.2292,lng:33.8442,fill:83,weight:166,temp:34,rate:2.4},
{id:'BIN-109',zone:'Industrial',lat:27.1871,lng:33.8183,fill:52,weight:104,temp:31,rate:1.8},
{id:'BIN-110',zone:'Downtown',lat:27.2650,lng:33.8144,fill:72,weight:144,temp:37,rate:2.1}
];
export const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
export function hoursUntilFull(bin){return bin.fill>=100?0:bin.rate>0?(100-bin.fill)/bin.rate:Infinity}
export function forecast(bin,hours=12){return clamp(Math.round(bin.fill+bin.rate*hours),0,100)}
export function priority(bin){return bin.temp>=45?'Hazard':bin.fill>=85?'Critical':bin.fill>=70?'High':'Normal'}
export function distanceKm(a,b){const r=6371,rad=Math.PI/180,dLat=(b.lat-a.lat)*rad,dLng=(b.lng-a.lng)*rad;const x=Math.sin(dLat/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dLng/2)**2;return 2*r*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))}
export function optimizeRoute(bins,threshold=70,start={lat:27.2579,lng:33.8116}){const pending=bins.filter(b=>b.fill>=threshold||b.temp>=45).map(b=>({...b}));const stops=[];let current=start,total=0;while(pending.length){pending.sort((a,b)=>distanceKm(current,a)-distanceKm(current,b));const next=pending.shift();total+=distanceKm(current,next);stops.push(next);current=next}return {stops,distanceKm:Math.round(total*10)/10}}
export function metrics(bins){return {total:bins.length,critical:bins.filter(b=>priority(b)==='Critical'||priority(b)==='Hazard').length,average:Math.round(bins.reduce((s,b)=>s+b.fill,0)/Math.max(bins.length,1)),alerts:bins.filter(b=>b.temp>=45).length}}

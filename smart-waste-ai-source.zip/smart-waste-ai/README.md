# Smart Waste AI — Functional MVP

A responsive, client-side municipal waste operations prototype based on the **Smart Waste AI** concept deck.

## Features
- Dashboard with operational KPIs and priority alerts
- Editable simulated IoT readings, stored in browser localStorage
- 12-hour fill forecasting using a transparent linear-rate model
- Route planning using a nearest-neighbor heuristic and haversine straight-line distances
- Fleet dispatch and simulated completion (empties assigned bins)
- Manual sorting-event recording and recovery totals
- Analytics and CSV export
- Zone filters, responsive layout, and sample dataset

## Run locally
No package installation or build needed. Python 3 or any static web server works.
```bash
python3 -m http.server 8080
```
Open http://localhost:8080.

## Tests
Requires Node.js 20+:
```bash
npm test
```

## Deploy
**GitHub Pages**: Repository Settings → Pages → Source: GitHub Actions. The included workflow deploys on pushes to `main`. No build step is required.

**Vercel / Netlify**: Import the GitHub repository, publish the repository root as a static site.

## Limitations
This is an **MVP demo**, not a live IoT or AI deployment. Sensor readings are simulated; the forecasting model is a deterministic linear extrapolation; routing uses straight-line distances rather than a road graph; fleet tracking is a dispatch simulation; sorting is manually entered rather than computer vision. No backend, authentication, database, hardware integration, or real-time telemetry. Location coordinates are illustrative sample points. Data is saved locally in the browser only; fleet and sorting sessions reset on refresh.

## Source concept
`Smart-Waste-AI.pdf`: sensing, actionable prediction, unified control, fleet operations, sorting and performance improvement.

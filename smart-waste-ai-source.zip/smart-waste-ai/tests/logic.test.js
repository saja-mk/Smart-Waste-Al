import test from 'node:test';import assert from 'node:assert/strict';import {seedBins,forecast,hoursUntilFull,priority,optimizeRoute,metrics,distanceKm} from '../src/logic.js';
test('forecast respects bounds',()=>{assert.equal(forecast({fill:95,rate:2},12),100);assert.equal(forecast({fill:10,rate:2},5),20)});
test('hours until full',()=>{assert.equal(hoursUntilFull({fill:80,rate:2}),10);assert.equal(hoursUntilFull({fill:100,rate:2}),0)});
test('thermal hazard overrides fill priority',()=>assert.equal(priority({fill:10,temp:46}),'Hazard'));
test('route includes priority and hazard only',()=>{const r=optimizeRoute(seedBins,85);assert.deepEqual(new Set(r.stops.map(x=>x.id)),new Set(['BIN-101','BIN-103','BIN-105']));assert.ok(r.distanceKm>0)});
test('distance to same point is zero',()=>assert.equal(distanceKm(seedBins[0],seedBins[0]),0));
test('metrics reflect dataset',()=>{const m=metrics(seedBins);assert.equal(m.total,10);assert.equal(m.alerts,1)});
